<?php
/**
 * pdoPage German Lexicon Entries for pdoPage
 *
 * @package pdotools
 * @subpackage lexicon
 * @language de
 *
 * pdoTools translated to German by Jan-Christoph Ihrens (enigmatic_user, enigma@lunamail.de)
 */
$_lang['pdopage_first'] = 'Erste';
$_lang['pdopage_last'] = 'Letzte';
$_lang['pdopage_more'] = 'Laden';
$_lang['pdopage_page'] = 'seite';
$_lang['pdopage_from'] = 'aus';
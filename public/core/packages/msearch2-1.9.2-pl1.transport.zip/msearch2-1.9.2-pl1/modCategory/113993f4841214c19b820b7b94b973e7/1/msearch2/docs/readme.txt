--------------------
mSearch2
--------------------
Author: Vasily Naumkin <bezumkin@yandex.ru>
--------------------

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/mSearch2/issues
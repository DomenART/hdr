<?php
require_once (dirname(dirname(__FILE__)) . '/tickettotal.class.php');
class TicketTotal_mysql extends TicketTotal {}
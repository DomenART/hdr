<?php

include_once 'setting.inc.php';

$_lang['adminpanel'] = 'AdminPanel';
$_lang['ap_edit_this'] = 'Редактировать текущую страницу';


$_lang['ap_ms2'] = 'miniShop2';
$_lang['ap_ms2_orders'] = 'Управление заказами';
$_lang['ap_ms2_settings'] = 'Настройки магазина';

$_lang['ap_mse2'] = 'mSearch2';
$_lang['ap_mse2_search'] = 'Поиск...';

$_lang['ap_tickets'] = 'Tickets';
$_lang['ap_tickets_comments'] = 'Управление комментариями';

$_lang['ap_msearch2'] = 'mSearch2';
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
    'chunks' => 
    array (
    ),
    'setup-options' => 'dasite-1.0.1-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3f23d6b79cf04817e596803c3f823118',
      'native_key' => 'dasite',
      'filename' => 'modNamespace/078db5f905657ad6a3462fa99e4d8d82.vehicle',
      'namespace' => 'dasite',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e3099262ee40cb2c10c44b6dae1522c7',
      'native_key' => NULL,
      'filename' => 'modCategory/80436b8f07fb98105f36c623ffe61130.vehicle',
      'namespace' => 'dasite',
    ),
  ),
);
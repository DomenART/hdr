<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e55c3cd8b611905562ed95021debcab5',
      'native_key' => 'core',
      'filename' => 'modNamespace/1524fb1ca8de412ad89a5aa6541e5931.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'a360415450a81d645a3c824a8459009e',
      'native_key' => 1,
      'filename' => 'modWorkspace/d7e3af3502db68ea9f3b5c6262f8c029.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '28169e125c8371be5bbedc62b7105274',
      'native_key' => 1,
      'filename' => 'modTransportProvider/2bf12af41c723663c45858aca70f1b02.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '08c2c5187535e5e0c99254d690f6dc19',
      'native_key' => 'topnav',
      'filename' => 'modMenu/223d159dea6727e2579e5fe024230228.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f7dbe16ca8a4b7d56cea80ede0ea1b88',
      'native_key' => 'usernav',
      'filename' => 'modMenu/c3e883f2133bb8ec245734a27873f021.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'aff36a6027ab6aa0825281ac5add529b',
      'native_key' => 1,
      'filename' => 'modContentType/e57f8ce743f31a8c243cf37fc895bac1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f1729305d3064adf4861ee3dce3fd385',
      'native_key' => 2,
      'filename' => 'modContentType/2dcc70ebf20d82b30bf4c7c4f35e31d0.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8c15389ba3a4caf6bfb2e1df0b0a8314',
      'native_key' => 3,
      'filename' => 'modContentType/cd0f2140cd93cd5004adf04df7ba8ca3.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c478828d594dcea08a7104b48e98199e',
      'native_key' => 4,
      'filename' => 'modContentType/b94242ae4ebc9657278c7767e4f60d58.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8303936b89b28e5dfc8a3057ac425853',
      'native_key' => 5,
      'filename' => 'modContentType/3fd910d26d6eda5d5ba4193227a76c5f.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4829e1999e3b91d2d920d832ef25bb9f',
      'native_key' => 6,
      'filename' => 'modContentType/12e9141a549b0a7f0bc182e254ed0d4b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '098a1a5945426c5d8140013c030323f1',
      'native_key' => 7,
      'filename' => 'modContentType/1265581f749617f17fc57b20c631c910.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '99a4f0a778f0463adb14836ad03dd7f1',
      'native_key' => 8,
      'filename' => 'modContentType/419fa3e7cece1f746c8da63982f6fe85.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '45870742c587324f7c71a4b60cd87d19',
      'native_key' => NULL,
      'filename' => 'modClassMap/62043383df3f02f57fa80220c1a63ef6.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '17f216130d0859b8b063e959fea8b071',
      'native_key' => NULL,
      'filename' => 'modClassMap/adf05e49a4208dbdefb79b8b3a0368b8.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e0ca9d5a01a05411b1c1f20430691bd1',
      'native_key' => NULL,
      'filename' => 'modClassMap/ef7e42a2f038afd3e4cad4408313be2a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0297c4a8d7c879e1fa2f51131287c916',
      'native_key' => NULL,
      'filename' => 'modClassMap/dace7f406606df81b77a850f7b28f91b.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '05f64312732f8fb8c2bd45139d511a71',
      'native_key' => NULL,
      'filename' => 'modClassMap/628899d0451d4ba4e2fc0dde9a0fe314.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ba7fc212d5d733f6a7afce88dadc3e5b',
      'native_key' => NULL,
      'filename' => 'modClassMap/ae5762409e3e9ec954722329975500eb.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9d44c64c8cc22a57d11bb690b388ddcb',
      'native_key' => NULL,
      'filename' => 'modClassMap/fe32b7f329ae11677184f7ea4468dc5b.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3c43a396a1a106ef07d512399df0ee1d',
      'native_key' => NULL,
      'filename' => 'modClassMap/25846f30fcce36daa707a76bdce344c4.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7a940563c5a81f0aa423cafea8ab23c6',
      'native_key' => NULL,
      'filename' => 'modClassMap/0657988f90e7009eec82c91da31effc6.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8314ffb0d34b1ae892f52045da79838',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/10d0a9bbbb254ece42c2c535b7cd2906.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '925f3d92650843fce94de8bad828ceb2',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/5bbec75eb392260de5e5f9ba707878fd.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f30faacb81d479f92b4b1bb9101e1203',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/f900f2853657368adb44a34f432278fc.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9c4e5bd79ed6c493c1f36f023eb30e8',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/a647bf39acb7acb8950fbb5fc24261cc.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69eead9223a99c2d35933bd63399ef17',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/05aa7d15bdbcc8f0ea13efe220a47a39.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d5085e511aba88f7396b9d911062332',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/0d0db6d28d76a0440d05946c3296ef7a.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '489a39f72af784f46a22ffe1777ab490',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/93da90349daacfa5a53f17a8a7ff6064.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85dd1fa5950cba60e6c2074deecfcaf4',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/73309af3a47ef213ae641d7d8c182988.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3def0239a6413196bb0a9e3ffd11d2e3',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/45ec78bb0313f5c9f7873ce915d99af6.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bbccc1d1dc0f12a9a9a3e032c032358',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/a63ccf64f28b1871c0a8cdae577e8fd4.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e91c887baeffdd5a46766f3dfac9ebdd',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/4cc76935aed82b4c20bc415290a4dd49.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83d7b5cf2df474de3ed74a6dcbd60393',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/3f9d6f5e1cde2e6a4ace8f94f94d19a0.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4691fdb814a7e4ecd901388ca31ddc19',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/4134eabc41ce5164af9974080297a126.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '160d21eecd9131d3ff9bd27a7294ff97',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/decea27a00d2b082b4b5e05baf1d1443.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '894ace3d2b495debf4ef9a6dd3d9681a',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/183f324a58bb1b9c3e447e800185467a.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '324e286961f6e7f89a7f1e790f999364',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/c21e0ba73c1921db802a073270400ae9.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47ef57cded3f3c07b190b284e7fd31bd',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/baf1ffe93f7f11cb35faf04d38335978.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e817c99a1f81448509e5e3c50f7a681',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/1a6d8ba18508a31ca8ed1d0798742343.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8c7945756ce077c38a64aaffbad960e',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/2c0ca9fc10772ff92f3b53ffc727283c.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9354e06016849a281d71c981014e967d',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/e27bbfbf12dc424f9f14e4e4fbcafd12.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '073192436cd48f8f2116e163b2d51ac2',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/854aca5daf53ef4812663603a7f6db9a.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da8edc484fc963a3fb6a9ca5a3b036b1',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/ce8e84b607476be00c082e24528f4366.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b777a69aae77e8fb12c2871f5d912cd',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/9846bad6c2a29a326c87756c410cd63b.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b5b3792004fece908f3ab5ee490933d',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/e6922cfee034652605ec0d1427f2f3b5.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c847c0feaa9303a375e2e09e8c9956e2',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/e3df67b517ca33e8afc6c6d3eef14b6e.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2e10582ab6479c292b5f02eb481b418',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/9650b38de04aca04307f8ec46d32412c.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fa499b577c03f08ae88f1a736e8f3e4',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/be433a6845da579036d1d022ccd95055.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6015b742c2b1411de18e7285e0f37f3',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/8aeeac48abdc5f0753c5687055ef3fa4.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a378aa5873b495679d50e1675e94d29',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/1a38f648fa548c00acbaad46e7b9f432.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ee1228455a8755504a802375ee81505',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/2d1e3e9e727b0dbaec29054cb5f7956b.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '913d7a694fd548419b76125730141172',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/5522ea1ef0c99ba842253af25a88fd0a.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae9dadfcbbe1dde1760f62eed0ed34b5',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/fc3c9dd915a91342146bf35c1c3fc4a3.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11de3de57260790231b8bca367a1a488',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/2c83054868d19c5d2d2fb895cdfb0788.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ba8aa8392c40a0cdf4e022301bc5c30',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/afa6e8148865c679e526f3ac65eb7c9a.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '107c48fa20afc4659b73585eb84e9db8',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/5c50538655814e2e55303a6f3e316556.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '404edce38a647705815a9994966cd3cb',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/ab709ada7536da9815a2e345c60626a1.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25551174b15be52d8c509aac4fd8bc92',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/6161494dc75d799fe9a84537d50462be.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2c6e04338e1a8b0ceba716f6f9b2a60',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/dc259fa0a03324ab6a056453a358f584.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb8efae2d6d4e77ade7026ef08a0f85a',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/1351f761f45d0762c02452b61f9d9da9.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f66bdc7099a695c66803d5d632eb3e0a',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/ffd09fc59625a60e56e166a2c7c04fe7.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8087de3acc030567997d64f8be0e6a96',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/33ca32b4dd0ebc7a7b7a51e21605e308.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd32f0bb135ddf72e2dae6196e62406c8',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/b4c01b65e1bfdc8d6671f8685a5b13f7.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f85562ec794df6c8011ba561c1a5ed40',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/4d8681ca703087b0240d76d57f19469f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '269bfb5d0738bb0090a36d9779bbbaa8',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/6a8492b4b942144dd53484e033409c85.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29fc96f2caa9110f58caa8f5d2fcd38a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/7d556415f2d2e9f14527b69dfdea56e2.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a18be702d76b324714935e40792c7be7',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/c36c7eaac465ab417d023fa07cb6a4ba.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cd2bb2f0e1c0c729eef767dc416fd71',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/2ffb1e314530d1e4f94f0f555a8a9c0c.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b793f7dbc710f2e4578f651515ef3bcb',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/c6e5f503d0367f359b9060951627ee88.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c6cb036b9ff85231966bd0de9d08aee',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/84cbe025d42b921afc6fde461ea8d89d.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17489a082cb34e4a21703afdb8f1f235',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/bc93efe7e9667ef7f0636a2a51e6c1e8.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48584d6ef1ae5cbc2f3f6787d105f452',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/86a97231b3ecb1d3eb4579d9c72c56b6.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bd7802453ec91dd5b47eae044498fb6',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/31f24d556b442ad7c3f18c94d013536e.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac692d65aaf1f839c218d906448f2b22',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/be76d3fba0a9ec2c4e1e38c3bf1834c8.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44b71cea537a654386746a936282f1cb',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/27e0df7c2681f7b2713fabdcef9ce806.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57e7e56b6917a91dff11fb1cc84cfb61',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/95789e7a0b0c4a475cca74356c33f7be.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '772ab7f1dc9666dc018c1c07dcede2cd',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/af00c9ef95d47e0b88830d4a41d3d4ea.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f69a13df88ec1365fc55d3da2901abbf',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/2e5dbae08949078ba14201171e1fda5a.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21285e5058252f3b99f9bfe765c10d83',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/1279c81e16617556e3e786141f9020a0.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e644dcead7fc0b35dcd06cb2856253f',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/efa9e7bb6d6dabffa3c663e33005b42f.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d9bca65915570594fa1c18bcb6c961',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/284ece62e5bb75a54e519ba4ab7de48a.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfd18e03d2522dc63480a371708b2d99',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/47076494523c28a14e12a7ccbba18986.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cc7fe9ed32838fc3083debea78ef918',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/008026e107b4ef815e1b8a517a0b6f75.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3375c9b7c6469ceea2328ba2e253f86a',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/9bfe9d90bd6d01c31ed685f41254a9fe.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a03d2661b11af51f37aa007542b595b',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/3e66f617ae70a9489020360c17304394.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9d08bfa9fa7d95b49de4bf7b92543e6',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/bb161a73fe8af5c334761b6825e3a8d0.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e69706081b49abbba747c7a9a7b77cc',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/96924fa8226692898ee346b013c4eee9.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98701cdf852fc95fe24d6ce8b5413614',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/048b04c9eb3dd387fa5698e7fd206619.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bca2e7f1e7e5e806faead8b95d0a8ad7',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/6711092f4792ee6e0450a39ce4c07f4e.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2f5dc383d444f7a5a43a9e428656068',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/a2c7c928912d60236580fb246d208404.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de443830f84b2480102cbb37d28868bd',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/f19ff0a988aa31af71bda4f3ea3abf23.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7d92885cb624e75f7b3fb9fe2294ad4',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/2d5ad110bc49925886bd957ef4155fcb.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef26c35143f38d81475f0e272e1eb97d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/0d800501010fc96b0fee3e0d4ca5418d.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7497e3905e05d0f19e45f699359c71e2',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/619930491a889038935bab49b6e1d7a4.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e36ecf7c5587c0ec0e91d3167b4e396a',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/02d3c9ddd98a5b0cdfe60c2c689c6581.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd158b1b64f40db01c07dc815408d294c',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/6aa5b7af203aa6376d69d65cfbca3972.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '811cae9d732e164c4fecdffc6a0d13da',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/320fec372e30b35edb773cb772153b21.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d378b8104ee252998d99443ec89f4fe',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/4df9c0c38214024d33611926a939d3fe.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b86f0e08913c34bf60a14fb248ba38b8',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/85822c90495027e4302a3619b8a858ce.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff59b8a4fee549f57e15d35775069b61',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/4a69399ccc930f8a85dec4daeda6f755.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6049cc0e28b68d320efadf3daa11163c',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/b7cbe2f69f77e8305f1d817e3886085e.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7900bbd2e11d168249f261f59d932993',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/889070c9a4bf2cfe336457c67942cd8d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd20131bb39de34fda0b9990b2ee8238b',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/07f974a9ac04ddc61bcad076734faf72.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51975559c6b521510bc7c8c633677dee',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/77a8bc350d6fc9166b2637c6dbcfb710.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89b9d7e4181041f5a52e2816e5f97455',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/2cad5b8fc4309b46f1175ec9c8e197e0.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03d7b1479e8fcbdf2e50c6086e03510f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/0bac78c90b300441fc90ee8d44b04595.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '060e25e456634ad252b6fa1edc141762',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/c92cd2d662a3d769a1766ddea2c76d90.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3f7a58c364b07eecbb9332bc8dee61e',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/561670fc5588784d93f17096b74d0815.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c6950ace63c60b6495522c024a84613',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/f15977ea50d0b364112d5e5da1f416ba.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '403223632adc7de1739cb87739c7998e',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/6dad9d85c5707bcc41a51c7925d7713c.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eab5861e0d8521a520fea5824ee76ddd',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/7f307513c1bb477c727838489887b1ec.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfd4aaf0591eb444e06af1278ba5af33',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/9250f42b40c65ff74f585bfe9039cd6a.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a0158e4bb3b8750605c840625573bf7',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/49348da5c2ec884a9849008df80c53a8.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e8d26351ae93e1a1cf2495b2aeda052',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/0e1e64339aa30785d8ca7a954bc60943.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac1c51d11fb4e6aac39b85f8f5748b43',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/a96d7b57c4677a7ef5e2dbf8ebbf4ccd.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '046e5bae64a231eb077e9a1a7a87eb0a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/d631c26d0ffe559f1992871868cba305.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bedf48e38b71e06b8a742d981546a6d',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/393ccb023cab933a21bf3fe9faaaae18.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5039e48c50be4c6edd72e1bfa736123',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/d93bd130bff7a905d2c01a39c49a5b04.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57ab3a95106796dd036e61b22397e318',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/1a5484ce506baacb971f2b3f26dd488c.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '514793a94ca9ae4e30b0a16b9d02a804',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/d2a2dc82298591c722b0c01b3de90ff9.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77469dfe9011e305523562da0e82c801',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/76cc59a75608702baeb3a50b0d1fce52.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7863772c505e6d0ef3dd6c3d6264584a',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/adbb27fa8a201ba92dc5458d81f40562.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02ac471e9dedff06e1578d9a81eb88fb',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/992e42d799f7bb4629b7ce1dcccbef63.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '071154b60447e64806c68e6435500033',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/8712d59f18f97e319f11f7f7b538df1a.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b687b4d02a2e2da2a1948b2ff237bafb',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/604c5ddf1c5f620194753bf317cf851b.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '425b1412ee3492fa5f3434d42a4eccac',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/1135869c7b7f33688796329cbe7dd0f5.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'faa4975ba04abb3f9364cffff1e7572e',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/40235efd0a1aaabd06f6dfe9318368aa.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '774b076527fe1f374c293797d5533b2d',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/e428112d43713b4ea2a316040ecc3966.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b41288590ecfa4c7950448ef7341e49a',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/27ef30a9dd76142acfa8c78411a2f2fc.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f687a702c620457e5ec13ef6809fbb0',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/744483bbea8d03b5d18a72f2c5260d7f.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e04c65accf22aa0be2e5c02b87fb6751',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/3135a3c1f3adf5914caf761a63fbcb88.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b7da19ff4a562cba460bf3ce43cf35b',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/dabc26c51cc3ebc95f3c77e7b7bf389c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd494e980f84b5252e8c62656222ce2b7',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/f01b0588a0743859618cda0e7b41ed77.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c67599bb7201f1492e2967c5e5c8d6a3',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/6627481d66033ec99caa1dbcfeab8558.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a351a80e0b94deb2f55ce8adb6d265db',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/c1687b4f0dbb0fb9db589f4e80c48114.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dbb12231218566e89f28088e95aa4a6',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/5d828bc6507762f3b896a9cf3c69a194.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3d7d7c64ea098ad31002a7e48b43185',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/a8a69c5d37c5306fd8289c89ed4365af.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdac66f00d60631a71cdcd8a98f20e9d',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/4c25db65f54012aaa28c4942ad23d386.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84fda71cc464e86edd2888c355343021',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/c4345bef4ab7c95f0720d78fcd521fec.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5bd2ff7d83d01e127bf79f6018540da',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/8be365bfde8802d3fa574b4d1a7bbbfd.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28a5d67e3ba575cd0463dde9f0452d49',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/6b00166498ff93986c7aded80d8a3b47.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd1548bac0aeda1e9a6c090ccea5ebcb',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/76f4e8fd5ddb2bba1f5ac73b622222b0.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '429ed3949eeccd59baf78f3f433b1a5d',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/8f4b27526019f564d38f084bc2072bfc.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '496794e2e94cd5efff764e4bc9541d18',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/4553fb95f2f6809e9ccfa89c3d17223e.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '279173c54ee1b75ea077e645aa3f18f0',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/690abf12e87c5a10654c279e167057f0.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af9479fc4e767b67b7aa0c046510aa41',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/59b7ad023f26cc37ad4e43d04a176c03.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a346587851e7b57c80c3d9456041f0db',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/da164756ecf95106d204179b5ca4ad93.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28f58b7133b7500c00cb08833f3060f8',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/eab3cf7d8e14244841e5051ee9b93e05.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5056433c49542786d7db6911a1fd9feb',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/0f09456e524103104f6a83b7b588372d.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d54e2c88eba9ace0d8dbe8a413169b9',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/665fd194f8ec3824180045e1b7dc649f.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '850cd887240d84826d854fb1b4a72614',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/1ef5716c56a22b98df8218614eddf325.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93b73d8c57fba77b7724d7b3b9ae297c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/258e2c8d6db25a2fdacc96697dd7b02e.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de1e19ecbbd5e5bd15ccb14d85028e30',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/eef4ac30d5076d86da7e961405a4b5a0.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a331e8fe864e578d8a23ca66175974b',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/0bcccc725f2ea2c7b3b143ec7db72c8d.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e492f74b9e4247eaae57dcdd7ef942d1',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/da41657b0ec3f72cdad59f4896ae13b9.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c95418a83e7bf49d5308fa1cf59a281c',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/9fe356afbf1eb0ee0f608815900e1083.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b70c62a3e74279411cd3aa5b99291caf',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/ed619bcb7a602073d98500c5004a9127.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0de271b1cb892b271c4b333af293229a',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/c9777b2f555f6c203ec1fc8e2106e9af.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f60d0b84867298229db6b8e42f04c6a',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/723ba59a51f56e7d496396b32574fe17.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2553b54cdc8b91d7ceaca21b4068970',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/4e4744745ebcf603959e08559e447ddd.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36afec06e4946dbea0f62c9825e1f387',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/77262e2116e9d5e3ffc3a5f1a06632b6.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b28708c777fe787d7c98a626dbe95567',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/34769a77c85760c3f6b1e43d21c48e5f.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f6d1531069fdb992043f356100296f5',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/ae0e503e5ee2d19e039fcb5f9775b8e2.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '255553928e275e21bf76cc1b0f034bac',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/9faac000c131fa76e9ef6401a6ad6bda.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b980c1da36aba479e15ec5cd9732b7bc',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/7911fb6e2b67ba2a4766dda54b0aa0ba.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43e0fe5a5bb009d98dda6f685ec96c99',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/4207f6c4bf6b6e8a165f96f056907113.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae64a825c164480ae00f4797c9613e61',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/d6276b7ccaab9c8902d18353f1c014fd.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1081e4af9d1206c837a90ee3c7e8d47f',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/b918faa2a493e60ea634ef9b9749e82c.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c514ed5c06c60ef8ca8c38a5c3632263',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/157cdde5dc002951b6ae2e7edab1f5e4.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbc7b605bbaa33586eb5c80c7fd061f2',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/c57905d9a6ddca317c6c4741220e4723.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a1f19d9aeac1f2406469e8d3c7c5046',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/95cf3549bc9d055cfd7f762e1029cc31.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ece1e73870c81e4bbca81f14209fd95',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a6582b63e91e62b9d0ede0cc0d5dca36.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0961708a399650bf812e608fd54a374',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/793c008b0739333a9cb8f9a173aa3cb2.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5a97269dcf23933c3ac7eab60c64873',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/a9d09965c3a3b18e77bb8a85e933fc99.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '516c73ad110067e7153eb08eb1178753',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/74fcea9eab531be0345848a197b9680b.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ab889ed134ead052847275dda881087',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/e70e115bd50e3209162053624146ca78.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86b12b7dbc31a8e87ca27d2f1ac577be',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/7072c4fd0ae56191d337921b5772ab54.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc051b84147004ffa6c93eb2727df54a',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/6a29ab464f9ee2f24309f8190c03e437.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f1dd55f421b4412233232b3545b7527',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/0155e73c87f8c8aa03fb7171186487c1.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a670c36ba97a8d816cbf921e80e8565',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/0fcff301166a4a566b93e47f26128a49.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0cd77ff94b7661c62eb26c37268595f',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/4d2b95c9695dd4ca65a6f996081515f3.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '042c22eb971391885edb52af4bb4179d',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/26b64215ab4ade80f859e0befb7280f2.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa5f6567b3e53fe2696132d4f30847ed',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/1a6c28b047b7a57290073d51e1f33351.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eccfc9246ae58a079abc21994c029cc',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/57c3b66b1e132704a6d8009a20b33666.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '593e7386888dd6eb2ca11adb5aba6995',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/ad16eed1a3c77f698ff311cb39d93c8a.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '910fecf78111b1dab973bd703892ef7a',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/765b7293dbc55f3d2f128bc7b8c9c6d1.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c6546caefd7aab87102eb9f61d18980',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/192dc1f583edc0eea0014fab38d4474c.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8207da83052dcef3fffb06c74be501c',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/39257b1a810e2414f2c039143e316b89.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d4cdd8c31085977ab77bfcb0e825abc',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/2b09ac86965c6d0e57b06c3c5c93be79.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72147908541b6f5eb2fbacf7cf5852fb',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/21eb5b818071f65b7f366eb3a756b63a.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88ee97f69eeef0ce9e51d0a318cebb94',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/e5a9f2f4ffe9a878dbe9b49a55426e36.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fac597a749502163bd9c708d96ed910',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/4c7d981bab6f6fc406fe132383b3c1a8.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84446f573102674d54e9a3ab7dbc7170',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/de71e2c45dea9eeee867ef96a451cffa.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '022dc33a851e97fe9e7fd30032fef77b',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/a913908294080b762e117c3dda78f04a.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1461c9b55b84ea4938dd54ac0f165376',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/7be3bc02b2b43d4f0dd71e10fd825746.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2fe25f2ee425739dda24e550351f9d8',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/835dbe25233f168a5be31e56f62d2865.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9613f6670c94d8f9ec0c5dbe70c730c4',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/79df813ecb90e71a367214ad003a4349.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98cb5959851f415882b28e714430ad10',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/97bd3d8a4ab175684bcc4a99eb3f933f.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '344e03a1ef3d398b1b1a2e941f7d2a8e',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/3a5484f21d8fede1ce22de66070b44ab.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '691a5b8d9994d26b008b45d7d5903e31',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/602f76ca1a035b6ffbd399e7fcd8169a.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '119d6caecd7949c4e55f311091b77d4f',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/22cbc254a7eb59cb0ae2a60bc329fd15.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac33ee8928e10755228b8cef50fa3616',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/76138924339fdeb3e14fdb53f1e1d7f0.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1e617a7baad08992e2b30ac198ae6a9',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/646c9a3f229232573d71ce91a44e954c.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ed48522e3c804f9a764122484574c50',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/2d4c75180c640bd6460fc7a67cab12dc.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b4b7886397d92bfc638ef7637fc2f32',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/8cf5d439acc0a792802ce0bcf1092040.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f75c00846fb69893bbb8604aa7b433e',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/b8ed5ea1b1212cf13ac8b25dc1967ac5.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d5c7750ea3d716146cfd3f2019fe34b',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/f50826b4354296b1c03c7e5097b44d35.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1afe6d714ddb03b470fda038fe877d0b',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/16dff65a2e1a3256507ca4aa837227bf.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53905942f2f9922b8dac18e1022a706e',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/408828fd9ba9f53ce16b5debe939aa95.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7330a6242293788b12072f205a32745',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/d07d59fadcfdede3458ee3b1cdb9981d.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '819b95294aca55496b50e88440730dfa',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/02aa1194ad5e2621b314888ed28caf0d.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a26678f5230eda75198f1d0610c6084d',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/b091a8e525d3ee5d657aec3e01ffe24d.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41bfb91f18c12b17c13f050d90ef9f0c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/8724ced340bbb9022ff7cedfbef868b3.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33c9e7b707d6b8380ab352a38632ff09',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/b9c0399fff111a2c65b4dc3d81d4bfb4.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad7b3707b3b482b9c6da726391941b92',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/2cde96afb4f41f3d9ca02b9b93bad33a.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19dd6a156f9e2c7e5f8166855d09b5c4',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/57bcaa560c5a7e8386cc39e4f3d04b1a.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850d1acd2f909565a4f48bf8b9b0a5ac',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/5fd990b7ebbd860eb6bd6d7a74cdda02.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a0a1d154cccf11c49a382e5910544eb',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/088e4a7816e818e4cc30c2fd18eed240.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc909fe4386e6fdde9f552be81892091',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/ae6e7eac5cc47e7eacec66d19550c8e2.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a900f82673dd316800797792322491a2',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/02ecba9f92f3bb125b562dd782e0271a.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0a9dd2a7b45a8745233d714a504d325',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/1b0eaf6ecd0436206e7a152ab4943e67.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff425b2aaddc8e3ec9082200efdeea49',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/0dfba00e50a020dc77a1a7c0f5e1616a.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e136fcfcac5c304911952c1d2366810b',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/f1b341a345fa5ae08f549d4d9a93892a.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '993632a8719737d8c2fd762e891bc0a1',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/aba6bc2082e61702f00ea75952406c81.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb91fdb9133fd4cb05a5a68b7421d1b',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/64a2958473bea90a0fca1db28ac6161a.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10249c14a6d13234fbd91eeb0da88c0b',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/6e701b855bee6a843307eae274429e36.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14c58493cf8304f6f29ee1273d798bd7',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/5c05fa041f074ea68723d603d3f951b7.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efdb98f286587040cde7f7ed1030f127',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/359f214072ce510b3dca2977cc2273e5.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de4013ecc08b7382fc7d5db674f79041',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/4aa7d8bb972c4ed8f10553b39b472b33.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ce4fc823872e92f001dd36fb52bedde',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/10de8f333c1f9abb19b5dea21d274e01.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1811a6c11472ec94e7b9ec3fb1286e4f',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/761ba4d7cae1eedf1dd70fbe85c54dc1.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1464e4602c6f86a549acb1218ed11d',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/793dcf114e7cfe73a668c33e675a9523.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d73cfcb32bb722b98f593eabf54ef34',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/4daf393732307dd2a10f9cb3896afb4f.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '322d5065d4959ce84a728402d68b939e',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/524118ca9bf7f681260aa79300f8809d.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d45f2ccf1bf9fe80f688a0cfa44086c',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3cea9087efe6cf9448be26a72c98888b.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ec947679fc029dd9c1c6a8829a166a7',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/4453634288a405cf3a0ef6c4d0d69495.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c715826276c4c735ab2a66332b51f9e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/acac2d801662e886e4175749c010a37d.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a83c24ea196741568022bdcf22358d',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/629939a97141abe0c0e7eb1568d61611.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17551462cc3a0b3fd9ae95a3fc723c0f',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/da57d4d8fad982c433fbbc9a4c95f310.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30ade362efaa390d4ab74d5ef756a8cf',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/7e404a16231868904d109d37462c79d3.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9337d72df910ceb9a80c4b74b904ad7e',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/a8089f6229c66ec13ecb504a13b35230.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfcda8a3146ca349241bafe9d59321d9',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/2a9f6aa016e35fea104174545a736272.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c02cf63cf648ce74b3635881160a88e',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/7e5515c7ab514f175e3065c6658256da.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d15efe0f2d74fdb859c46e2dd57fb35',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/aab78287138f9e013003ac58042fd0bf.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a192b67c57ecd1867e666b02e29feff',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/a07db2384c8c61070d11351458c14145.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65d07d2ae1ee72b9bddd94824261a66e',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/aa58ff4d05d93a21e0441426060fc598.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c539c71de7ca130c6201413e49ccc7fe',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/389e3f5c9fe457b4e9b979cbe2756989.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe9ebd78c83336818f643583dbf2b952',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/7cdf2b2c6f44d1361cbe5f7777f64fff.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29cf9430664ef45d2b4e1fb3f2a10d28',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/8d80d91b604677751959823da3d6023c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89ea8deff40afa56581a635bab35ad3d',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/40df52c00a2f6ba7964b2d6c29a2536f.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daa0be0c2ff077b73b36a5a86587b555',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/903d4e97f6cdca05133bd9f7970aa92d.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c1f246a1e76ea6db6650bcd4925e185',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/d80e2fe8bdf816c3d3989f7772be8f5f.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc034bbc4e6af9d3f34d5fce76faa7c6',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/a4e9a971d721ffa915244e2973a4d54e.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10cec071d9e8eef0dbdf1c0c2e53ed01',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/ff38f61bec774decc04f94c62e2817ab.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e84855d7fa43df62dd1c5bfa81506c',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/69a79c4b02fd0992eeda6245a8bfa8cd.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd669bf83f59ddad02e47e6a274036caa',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/f7a1a7380ca1ac50a0b30042b93f92da.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efcbcfbd470673b94d2efc6975a58f97',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/4fe55103e08894f571ae3d9035fab553.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fa9d0c1b6ffcc8b508f98d4019c9e06',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/a5c71dca69111414e70737670ac51a32.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4cdb6a1e59d771234225be72cb5207c',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/e8a6f8573ecae22b1ee2a26c9910defe.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1b388b66d475f5939c88645abf87ad2',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/d9f511f548be58a24442ca243f815bb9.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eda2a6a814a7c074041c434898c09bd',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/904770bf50315c3d9c557c1845a2c6c7.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec90986f65901f6a8d7edaf088de7e07',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/f04c9e021e9e5d6cef6740fbb3ec8081.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a01f2c27aa043e7581e68fbce71311e',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/51107ea4b82eb890c7c48f38ba7ec6c4.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a2f41e7f4543d4015d1dbccc046975e',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/a05519232035e8b6505b822ea595a1be.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ee8a6d7e15f3044aec285c5bbd3db4',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/4323a79142fa364177d33c572b79cc2a.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55cfe462a541efcfe0de0d4d556a2759',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/7034eb358ebd813949feeef08e23c166.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473d2fd274e41d0a64451ee1d9db59cf',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/c5a2388b619c2a1570403659775cbb75.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98b6af489229dfac05af34edea19eda6',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/569049b441caaa1593657e1eab405131.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '998f07e443713dbcbf7ce578722eab62',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/52a28fdf332f77b9bb83289f996dcdb9.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f06a16348c4a9aa9649655597d713cc',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/5c173bd54699a696eecf1bd7afd96972.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eb93d8a85026d187411563640efcff6',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/a96c378e315c1a724e52185bc086fc2e.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45aa6cbace7938281bde5206b4389ad7',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/58203e0a46b4088de0cc26b42c106fd8.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5234f6f7d3a70fedc2c6a84e8531643a',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/d5302c0706e2e36ecb0d281ae375c6dc.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba9f8a04595e3ac7301a79d1d69278f0',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/81682fedc3f6e84fada9fd61ebfdaeb4.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25fe83c2fa451d8be5c82a956546d792',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/44dde257f52c6f4091b20294317d2727.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35e0360f3f21a5eef92748dcb2db6561',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/7583097420a1f6f9cf7a561e0e5a30c1.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '168fb7a401340a4d6e98dfa4f796a52c',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/558ea0fe951a90476e512483e8b28b29.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f380653fa1225237b67133c2746b0233',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/a5c5785f98e1ab490856b95ab686506f.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b1f884537460880cee036557ccf443',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/774be89f02b75d07b375a3e1f9754382.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '696ee90a96759a1dc40479fe715db549',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/53395fcd3da095c28a43b4dbc5d60042.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf236900d1dbe107066a60e2d6ba35d',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/84c7804a67b02a16303da429c71424c3.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16fe21205af38e77c7134442ad339509',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/5d9a81576b6c72e5a545d0994961910c.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f6156a4c66eb519ef2c47856a998ef0',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/23c1284803081833ee54f3ce548b26bc.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '531ef7ceea12f8c1d1142ebc37cf0105',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/f83a18f0c79c0f5f8ac2ea623713fe42.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57b0f8d154c5260d5e8b226214094eac',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/bafdc106a45316b7cb003268b0a369c1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5b3587c4be84ab970123a3f9c8ca248',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/5418c52b30d0d34c3d05eaa9cb7ae048.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace0b236771d20509df3fb8de6705678',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/1e35980895f3d2069bbe10e3b62d72ab.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1df7940fafb2f4bc110bdc525ad3dc35',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/9ad44aa38712296e43e77c72c62bf1f2.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1a94d5e86b3ac1c6d57eb2d82b4756c',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/8e8dda966c78aaba9692d5c14a735de3.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3c04e2499fddc462d8a82edf3d8fb96',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/a8aeaec287d89d205afb9d54d47aeed4.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2fe7e41832aa3f37450af9ce61922fa',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/38817039eef98eef0b90df1c233f80eb.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a78d70fc98725a8b771b1f332f5844b9',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/2344090d79c16547e36dd2bbfb9ab118.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a212248c4be55e565e9bc182d2a66b',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/4b1dc67430da4e1ac1dfa0278ce41225.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62176dba8d882693b59044523b4bb2a6',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/1bc350b1489264318a0285bac8aa9e47.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd0b5e5335af6d2c32b525f211a38937',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/b52b996da5f6e9ac45772227bc4f69a9.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c02f51977cb7b769b3f9ad53451f2f7',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/cf394ec6e86ef2e5395d3bed28a54efa.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9d2d14e1ed04e74e8c9685d8f8fe3ad',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/63bfea2354319ab7842835a842e71102.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7659b10a9f9a3956339557ac62d37b2c',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/04d2fc37d899b6a8145611546eae0dc4.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f27eb5901505c257e5ae755d7247ac0',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/914aa9769408cb4c639d6b1d10c02dc2.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9719bdd1efc43608bcc3522251259de7',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/09e8d90be6bcb8686f879df6afb737e6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2010e0458d34fdbf60840bf757bc698',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/d234417454949d31f7f3e3653f316604.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd01412de0d7dc95fb9072ccbe4dc61c4',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/82eefe59f5e4085ac83f86de35df6595.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f25b210bcdf87c068d49f80a9089d748',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/6d95ed7ed06185effa18d059d238c93a.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63e7ca693b8b44c7601082726796aeab',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/eb39d733778e5db5cbdd362656751655.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcb6f1eaf1e71c9805c323cf723cf2b2',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/582b604ce38408b42bac45b0ea4f46e9.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf0ab58845abd337d47e850ac5a07a92',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/e2434f7b8550b2f24ab0549c97980491.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a32ea21550f3c85c5bb04c8acf231e3',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/2fbdb14ed52488d76f8ff0548b862ac7.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e137e344450da9211c5c68cdf9a14cea',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/07e4f5ecc111d20718ba696a3a90605a.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4f044d7f422d5b27653b60770a5d55a',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/783e8a0b05c9c3e02addf642fab859c3.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3676a191290781ccbaa42eb678afcef3',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/c3474bcbe57f3e122e89107b6a68dd13.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54d8e2014396bac1f29f556225e84299',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/28868d9df73bf1135ac4d16c50169b8f.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1884ab890992b3d71ef9d9bdd6abdfa2',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/de4c77e1e415ca3c325f5c6f92b8e8e2.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54c5903970cfde9b4a18376013ea4554',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/7fe2c5638c80d3cfa1adc9e0658cc7f4.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c7b102dd97c96e962b79051728e9dee',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/783f8edd7bd00b8fa37148f3a58c3e76.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d2b620cba55c34ffeb516655faff8ba',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/5616451b030121ad79cf5670eae40bc5.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c36e55e475307257b12ea49e7aae8bc',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/5ea8424d880c88ffda657186d2f23c65.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39fd9f1f75e48250bb5a8f857d6ed008',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/e22fd064345e19b03fef2120c60b63d3.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20516f70c2d6c3fd515f6e3441627af2',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/b10b7f938a0dae4e937469ca4a19c6ee.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffcf36152765c02b5a28a60df54d796f',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/e143721566bc076edd6a63d437b3a3a8.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af6372a852745a07acb10485fdefbe7',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/79e9788a76a18c1bf44561612f111db6.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd230743a879e6323587fc3e640728f6a',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/1e78849c6d561420422324fd621edd99.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef99b32a38e6ac7bf8bc26f93b2403ad',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/eb6390d866aa57bf5de76a95307c78bd.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa1e894bf55512e4f101cd2252fa77f3',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/51af64cacfaf742a563083bba8272742.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc820f72893fa28de02537edd342cf62',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/5629c6f6a97bfad7efd4a2f677ae9242.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a5485a138e6696f105714001db48a93',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/02f2ba53666d86d149ba759903f11169.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e47e651f1c4c4671fdd0bdfbdc0609e2',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/135aff30589b10eb8c403d72b28e9be5.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f596484c3f47ccc56f475e2f4a4e456c',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/5521e1b6a2038021a3a94603b4b8d784.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d84e15921345fa3097dbc9237d773b5',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/4950e1caa8a343d9fb38a9775fb51f42.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a1b49c38db8d13b01f01a53e53cfe2d',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/eb3258742067a16baa4651bd0bfda94a.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07f7a4ce518f5c479bbbc5255a79834f',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/d0fcb747a2dbf25909acff05ac5fd5bd.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4178885700c27f86cffe335d5533da10',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/22414558701ed9c9efd6521bcb96dd5a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace4b5c76e28f5f16c6c8391f4431f35',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/bd18625f71228d5164d7d93e5b981c2b.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f8a3de9683ebecfa3d4055403d12957',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/654dd9525303ce4438670112039803d7.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17643788afddbf6a66673f2da9789b21',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/4ec7d0cbfc2a7104612a8a40439f6d84.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68d56db8da5b05761a51526dd0bcccef',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/6c7cca8ee099fd841dddc7f0ebebc4fd.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db9be1eb36809272554f27756d7da96e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/a0290f06e899e42ac867468893d49056.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42d32519c5fd5ada75bb6c95c201179f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/178da72cd459eb30c42192beed88d382.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43152754ff879380dfd71a33bacd84da',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/42a324ca449353accb45a2452e1f791e.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb3d1413ae1f7513a7a5d8062ae58da0',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/bbd5d8d9ca0de0045b0309dea700eada.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f2a90feb13251a76d5725ae33a3c1ef',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/147b315912501eaa4a69477c809468a9.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fef770abc7c768891254e7af7340951a',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/3fa620419487da1d91cdc63f7938b399.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '634db3863157cf6c5f99c45b2bb45075',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/da3981b89d7138d65fe056569c805bb8.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db9ae2b89985628000f4959f0951d11f',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5fc636491eace685098be7bc0a5f34cd.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cf16aad420f73a89288d61182810caf',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/abdbd19a23076f5a799f21914003be9e.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c1557c4b115cf87040c5b46911d8d12',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/f6eb64aa3586795aa5b3f21dbc1a383c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4a78bdcd4c3d1ecaf35ea9069b606b4',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/b8ab1f167d244728cbd78f9f60dc78a5.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d7ddc9bc6212cfcf0fcca605bbf05f',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/c993dcda1ef076668ee2a01d281a5f17.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8308acaecf00db52b112d5071307ca07',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/b153680c5fbdee532c987fc4a5928c98.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9db1042d2d57d5b58ea6a567a785186e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/82398d834a0f3a8b677ec11c8f9f9da1.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a789e91115d4e3633361af5d098a7f3a',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/4cd0bf6b45a9a4dc74a285cb6bcb89f7.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c8abd1c18dc682fc30fe5d9fcd64409',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/e9b2182a163a7f291a692f144211f554.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd528b5273b2f60ebb1ae6c1d8affb440',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a8129c45e315d5c1688aae20b756fd23.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5815f4aee7bbf9df4abfd2c1521492c7',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/8071ae8a46d1422940de2a2918305333.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d350bdb5f57456d74b6fb99477e00d1',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/28d6679b34c384887d47a3cfc615735a.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03757f73ec82c3f69528771705cabe22',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/3837429f6ba85ebd18115a72037126b8.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdfcb28fa19da476abdb09a9b5194080',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/358d31221912770fcf2fbae1fb1b55ee.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5d4c4aeb7246658ed720cb57f232ea9',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/ee67a19952b5515671307c762eadaecc.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03d370e66bab2ca50c3080b6cd778834',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/da497fedd7078511c294fbce5659abb7.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '937460f4aea1fe44a323ff3f848f5259',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/71e454a5219f943b1a99fca03ad2a0dd.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79c80f545c195046427e2a1656e81a4b',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/7ec3d11489351ba0da2879b6d6bdd0e9.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b9941711d7b17f946ae8998eac5bd5b',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/ccc0278a41038ced5d4546d8d141dfb8.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ff1d0dc2c90a97f299fbbc01e8f44b1',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/bfe7909a927319363ec8d776d49426a6.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6617b4f10188d3f76fa54a8c78b1c037',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/3928a98d68d17e5d6152e3b8cf9f4c2c.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0495b6061f48551df9ee0090d29bc5ee',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/8cd10158ff520fc7c3c237584cb8c3e2.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58290f5224ff333bf676f8a44c4d5b23',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/e10f4e721c49fd8183616421a0c966d7.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dbd43b882e6051f3905245f96fe9069',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/80b769397234606f7a3c2a4fd62c3a8a.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39df1bcc5188559c607a61fe4697a517',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/4cfb5029fcf74fd6799fecd1dd73cd15.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dccbe5a1d837b40f57b361417e8a6473',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c3b60996a14d2f345bcb8a663ca8975c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8c176a5707dd5d44d23f34bd49f2d36',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/d497fa475173f0a8ea5f522230968cd2.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba2658af8d138c97e4b2bd103d168f19',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/c5d7ab9f17d7a01c522ad5aa7f020e7e.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed04b77450bd783ae0797d543ae78aa2',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/1625111429ca785722895cafa0833cbf.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d9b8de3c4b3381c17b89bf1ab9226b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/e4abdf2d677146c9032dcc8b396a65c7.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04181d412d43e59c7be9048796443ec5',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/e28b9304062ce71e10db6e0ad6da4a85.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48c21251c385a0b3c7bb596c05a24992',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/e4c872abaa9871a6719c86df91cdfba4.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a4de81eb5d900c02462a2abb77f6d19',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/4697c8daf8391863d0f3930c1c1ac0e4.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb5a4bd9664a5485bc43373a039dc1ef',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/0135e945c2cff77cfab4f3e676900813.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96036a22efb2c53eb2b400b135df066b',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/6aecdc2417f13658d0be6dad39936b68.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e95e822f0d7885a70eae49e90ca3af1',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5c7b3cce43a8067d0f957f27b2845a8e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30f52aa32c8a3b8f7a7eca309ae3b497',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/badd8fc4205a66c6d455f4f7a1296290.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ac8f63dee5c5131ce32554f74d42388',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/2d6bcd4b2fb1e6429786c471c4002bf2.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25fb6bcee10eeb26a189c7f9b7544b75',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/f6d8bc21f01d209c914d7340e0188820.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '259865fee85378ee758cf73b35da1b44',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/99ba76cfaf966d650265b9423813c6c0.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9179b995edc0f76cc834bf67b20bf61',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/768dc2c1fa1017eb8bd8363b384101e5.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bf449e389b2c6d9f77c5bbaf554cd9b',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/b5a178dcd2d98f556f1e6a8a604a6233.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd203903174f32e1b756a6cc8bcc58fd9',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/6ef060dfc4afbe86e58d71064fcd9ee5.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9c42429e066a413d61cd67f032d5eaf',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/089a83957d366ef7231507242772693e.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb6fc3a4283f28903c2a5dc6e987f99',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/de1fa8ec7374c3dbb292e75d5bac11b5.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6f270b65cf1072e9f25db01e3ab1e53',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/852518b9be6f8220534b2737b793a9e6.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7a5831dc01f8950b50534bff4280d8b',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/d1e2ec8ac9185cfcd4f38677f0c903a6.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8c28ee6110f7d039e263270db3ce87c',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/898dc1efbe6cc81e581abd22c3581b7b.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6f4211b0ba40defa3fa10c73b385596',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/74315c77e1b90aa454226e3ec7c874c6.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6076254e3ee5a994b71333d8f295d190',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/284e93940f86d7eead5769c26baafad5.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f26c475fd0e26a65d9192b5b9f275188',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/f804b9d8fcd9ad389205d9190ff9dcda.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '711b453119ca5e9689b796ebaa35a25b',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/c671debf3f67ed97430ce5c6269165d3.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5a14519edc67f40c65dd3ff6e671f0',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/4ff9e7a57e03fbe21101721c2868a0f9.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b18f031a4a5b3ba64ec567233c293093',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/eb0efe215b7c6f6e9b877bfe48ab2500.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aec5d21bdb6102e42ff41b833c0eea6',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/4798c9cdab351168386dde7f430c533d.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1d8f782a97da7ea2ac5317134f05604',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/33a24c45450c075afdca8591f84193da.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b89c4e413821420f6a2b4cd255ffe04',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/9b27132ebc661db968b112b1a963a7be.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35330b997830302964c6780835e5b42f',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/19a765e8a2cd3135bf38d73c300ad403.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '867ade084999a04d280ebfcb3d383a0f',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/e047a193f512a6bbd059f58a747961fa.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7526d058d793388883ddfcbfd68a6db3',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/c497c4f49bd9b29acf9a5e82eeb8dfef.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37ebf2669938b26c2623482e3ad39047',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/50f2a586a68109ffa4f5805a947d25c4.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da8598a09f5e5421bd506230551541f8',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/21ef086e9205438796d4b1ba11840872.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2790501620abfbd0c6926ab09760175',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/cd5bca33149f1084c786240178f875b5.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2d7aa8770c1709ff2c748a8fc4d760e',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/f60b9505c092a8d4d3bed6f5cceffed9.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1bb2d946d1762ee1c1a2b2c2869846c',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/8dc2c2dbf755d9ddfbb348e70d64b57b.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dee52c0421b92618dd4f9400b3ffa2a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/8cc03061844d684d7e4135a3c06fafb4.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41bfec52c9ee9f17fab8f42892df9a2f',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/58681dd6af0ff7a7b06b495c4b8e7429.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe443ced36b660e524a68e8ee77df8d0',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/6068068c39fce689645a0bdca505d39c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2cc46d03cb5a42574b1ecfd6abe8d5e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/acd0b960787946ab9982dde2646f4180.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64cb61bd5fccb13aa161938bfa34313d',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/f182493dd5654a3457c1a0310ee24b0d.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec1568feb407be76a21082818dbd9bfe',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/13c0666eae0058d5dd8b6a4818e40c61.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daca17ba2a93184d7450caa89b8a7932',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/9dfae8df9627f1344e5539af55d22aff.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab543fbd4d6964532f70f6077ca2047a',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/cc2d2e104abc7e628f4b3d405795cb68.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd723ff266ebe14e38860a690833b9545',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/860b85b6a2e2a3f7b74e74d9e9fedd88.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '972d34af53cc9368965ab2088075ad57',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/40a9ab10b1a865bb8825b010075f3aa7.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6dcf2ce65c90e07b55dd66d38fb5827',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/6334a4b730c611b7e7f2769fb3ac4467.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fb58ffd2723b402b88bae872ebff89e',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/827343d817a18ac9678b0fa5508b6974.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63577d2b74cc5cee20d61de6f71bc9d6',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/1f5b179c0e8505a87440ad51466f8102.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13b93ce72218aa4438a907c4d0c3fef6',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/2131b2294c87a881e3dea1c5f0ec30fb.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fda7291e1b60fc4a13dc6fc35903c235',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/39a16fbcbf3ef8a3a0ce10d956426d15.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '320bf8853903505f83e222095fa70a85',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/14d98db2f2ec40a1bb8ec0744f8eab9f.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72db565dcd177f56338b0df073cb7ceb',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/c08d127f423fb218b2b4752135ed269e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bff6479c95e5032dd446df398f38086',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/7ce8c37c9d536bf1cd58717bb8f30215.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a785bb5d2ce0dbc87f384d9a54fecb95',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/17ef4b9cb3e87eeb5c16decabb612d5c.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f5a91a5b14ec04a140f3e30ced4cbe2',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/503465e37bc8dd29780eaf6d88b00641.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '95e6ddef30afe1ccfcbc94e8da039c7c',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ca078cc5bed7f202c74c65afa07f0e1c.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '741c81915af04aad88e2d44a4c5e78b1',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/f8ae8707ce8b1b3b58a3b2367e06ab13.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c0929a8ea2244ae301fe0e81119ac558',
      'native_key' => 1,
      'filename' => 'modUserGroup/5fff9420e479114f5f3ac86452ff8134.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e88f27c81acc4f0e32ea240f1e9d3bb7',
      'native_key' => 1,
      'filename' => 'modDashboard/4ac6a578b1b1f7c973d5b7b22a2be346.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '4083812b76ebf21dbd2b87b98a50753f',
      'native_key' => 1,
      'filename' => 'modMediaSource/b6e8a38c9050a3ee0a1d481629b1f190.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b84ca55c0006f9e5f859f2b123d33dfe',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e455b5ff1b2e92d46b92f5116c1e24a7.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '00b2af645c84a8cc632a9d73a5b524a4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/0936944733dd742157da04c43f089054.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '13af2c89076a4842f1294054015932c9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e53e994f461c55dd81264ffa874190ae.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9b71cbef2e88deb01f95d1763f5cc4df',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/74092c7326807cd6c9b47b036d6b4745.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8bff109fceb1def0ddf90a35e60da7b8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/1686baef9774769d1a05dff7b962a40e.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '2e6b7d455ca3334bbeb8e7210444c4ce',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/45ae932e09c81dba9adbe0db7aaff5e3.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'bea969c38e6b6c628083e86643eddb42',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/fa71e0739f6182ad0fccca11a899e264.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '562f90a4a585e187763f443f77101d5d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d95344e1bb0108fd7def63131e0b4e70.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b0de07c260f713e38501f1cdf2549df9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ac62d2ecd9bfe00e7c7eeb22b41b3d30.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'db4b378ab6378ee08d227f81e6621e9c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ce73bcddf04aa686b6844c3d5544b5f4.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7d0f853574d1459efb8feed4b4f52b7e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/208348918c5360f32f92831e4e020bc3.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'cd1b8b28063999130f6b107d6a94ef17',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/aff60fb3e15f5de371ade6066886430d.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0b6af169017f70185a6f231ed2e96bb9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a5f1ab106db9a20ada18c9675860915c.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '81d1e90beed95632cc3d5af4b9ca421a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/174504c11eb7e69d159d7287241b4099.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5d3b476039b438e3185f4d4c8c06db65',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/121a69d985e03a1fa9a458d0bbb06b94.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'df9a3f5f62d4576a92b49987fedfbead',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c8ee467586b4c253e5034eafa613517a.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '84b6705e8cf2e05427aa6dfaedb07d23',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d734632902627d5b93b2c75e8760f2fd.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7da14c820bcea3953c2aa803c5813823',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7d373e1fd0371a4a08008a9ce2916d69.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8e059ad6f7d29c69b045ce9e56eb3cca',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/96e8168163d657af398850b445c3ba9c.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '26ba7079b7d91178f32ad24d72280d91',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b650ae596cc25fa4658e8e76917724c7.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1e1c3856a0967aded6a6cc122c1a73d0',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/336df720c676f9fb8453cbc8d3a1850c.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '32bcb67bd9b07af87aa772f07c44dd72',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ed3448122027083a88f42fd2024f3198.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd4f0b02fa43cd9905072fe7cea4d84b1',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/72a53f8642b92996633fd98d0d4ab4b3.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4d1e86b6218c26eea1a8b194327b7e73',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/a09320909f938d60fdd2ac0e87840b7b.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2943e464f3cf9dbc591cce48888418a4',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/dc2412a86566d20f1c0f852a30815d9a.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '799a28505d4f293af6f93f9d9027c1c4',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/811e62e613c9db8fe2a807bfa7e81848.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '73ab37a79a265d89caa8b8271fee5105',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/17623804bfcbc1cae7087a68eb8dc099.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b8c5c9896e9117df87b218ae1b560c8d',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/c26d5bbf632d850499850510ed40aa9a.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f0d9f6e5c27aa70b59f4d4618f13c1d8',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/02422ebf0a6d346dcd5b691765e5b9a5.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9c578c87235d1c371f2ea91a37c3d582',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/31cef5ed49748b83149e6dc57650519f.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '18b165cded9cbd64225dab5c22b46ef2',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/a7fd1eab9944d2bf89e84ced00ebc7d2.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2a0ed212c6505ad4263f1dc440e23bfc',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/fb7d60660a4e141a6c874cc59e1c52fd.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4e0ea9ece3d5c152dafb1c9f94102fbb',
      'native_key' => 'web',
      'filename' => 'modContext/a399d294d132299cdf22f59219a21271.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '56d6a1914b21edff9623af43dbe4f359',
      'native_key' => 'mgr',
      'filename' => 'modContext/e6c2cb25a00ccca986aa6891d56ac2aa.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '339aae2e13480f60b8f3c23dc2f3a8ef',
      'native_key' => '339aae2e13480f60b8f3c23dc2f3a8ef',
      'filename' => 'xPDOFileVehicle/006d0193e56fb8deaf22d8e05dae9121.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '23dcd206675d60517c2afac0ca9ece01',
      'native_key' => '23dcd206675d60517c2afac0ca9ece01',
      'filename' => 'xPDOFileVehicle/b6bdb1d34c94d24f6ae51c753d7d1ae4.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '694abb1b14580972e329f1edd54e5924',
      'native_key' => '694abb1b14580972e329f1edd54e5924',
      'filename' => 'xPDOFileVehicle/c5c9539d8072c4a458ffe323a3a9c9d5.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'dcbe43b504cc64fc2e0e33e9b591cda5',
      'native_key' => 'dcbe43b504cc64fc2e0e33e9b591cda5',
      'filename' => 'xPDOFileVehicle/7c50cb0ee67ca0d2340bd2641b09d398.vehicle',
    ),
  ),
);